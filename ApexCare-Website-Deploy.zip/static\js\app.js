/**
 * ApexCare Appointments - Main Frontend Application Logic
 */

document.addEventListener('DOMContentLoaded', async () => {
  // App State
  const state = {
    specialists: [],
    selectedSpecialist: null,
    selectedDate: getTodayDateString(),
    selectedSlot: null,
    selectedDepartment: 'all',
    currentStep: 1,
    bookingResult: null,
    activeTrackingAppointment: null,
    isStaffView: false,
    staffFilter: {
      status: 'all',
      date: '',
      search: ''
    }
  };

  // DOM Elements
  const serverStatusBadge = document.getElementById('server-status-badge');
  const specialistsGrid = document.getElementById('specialists-grid');
  const deptTabs = document.getElementById('dept-tabs');
  const datePicker = document.getElementById('booking-date');
  const quickDatePills = document.getElementById('quick-date-pills');
  const morningSlotsEl = document.getElementById('morning-slots');
  const afternoonSlotsEl = document.getElementById('afternoon-slots');
  const eveningSlotsEl = document.getElementById('evening-slots');
  const stepIndicators = document.querySelectorAll('.wizard-step');
  const stepPanels = document.querySelectorAll('.wizard-panel');
  const toastContainer = document.getElementById('toast-container');
  
  // Modals
  const rescheduleModal = document.getElementById('reschedule-modal');
  const cancelModal = document.getElementById('cancel-modal');
  const printModal = document.getElementById('print-modal');

  // Initialize
  await initApp();

  async function initApp() {
    // 1. Check Server Connection
    const isConnected = await window.apiClient.checkServerConnection();
    updateServerBadge(isConnected);

    // 2. Load Specialists
    state.specialists = await window.apiClient.getSpecialists();
    renderDepartmentTabs();
    renderSpecialists();

    // 3. Set minimum date to today for booking
    if (datePicker) {
      const today = getTodayDateString();
      datePicker.min = today;
      datePicker.value = today;
      state.selectedDate = today;
      renderQuickDatePills();
    }

    // 4. Setup Event Listeners
    setupEventListeners();

    // 5. Check if URL has #track or #book
    handleHashNavigation();
  }

  function updateServerBadge(isConnected) {
    if (!serverStatusBadge) return;
    if (isConnected) {
      serverStatusBadge.innerHTML = `
        <span class="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-emerald-50 text-emerald-700 border border-emerald-200 shadow-sm">
          <span class="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
          Live SQLite Database
        </span>
      `;
    } else {
      serverStatusBadge.innerHTML = `
        <span class="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-blue-50 text-blue-700 border border-blue-200 shadow-sm">
          <span class="w-2 h-2 rounded-full bg-blue-500"></span>
          Offline Local Storage
        </span>
      `;
    }
  }

  function setupEventListeners() {
    // Hash change
    window.addEventListener('hashchange', handleHashNavigation);

    // Date picker change
    if (datePicker) {
      datePicker.addEventListener('change', (e) => {
        state.selectedDate = e.target.value;
        state.selectedSlot = null;
        updateQuickDateActive();
        loadAvailableSlots();
      });
    }

    // Wizard Step Navigation
    document.getElementById('btn-step1-next')?.addEventListener('click', () => {
      if (!state.selectedSpecialist) {
        showToast('Please select a doctor / specialist to continue.', 'warning');
        return;
      }
      goToStep(2);
      loadAvailableSlots();
    });

    document.getElementById('btn-step2-back')?.addEventListener('click', () => goToStep(1));
    document.getElementById('btn-step2-next')?.addEventListener('click', () => {
      if (!state.selectedSlot) {
        showToast('Please select an appointment time slot.', 'warning');
        return;
      }
      goToStep(3);
    });

    document.getElementById('btn-step3-back')?.addEventListener('click', () => goToStep(2));
    
    // Patient Form Submit -> Go to Review Step 4
    const patientForm = document.getElementById('patient-form');
    if (patientForm) {
      patientForm.addEventListener('submit', (e) => {
        e.preventDefault();
        const isValid = patientForm.checkValidity();
        if (!isValid) {
          patientForm.reportValidity();
          return;
        }
        populateReviewSummary();
        goToStep(4);
      });
    }

    document.getElementById('btn-step4-back')?.addEventListener('click', () => goToStep(3));

    // Confirm Appointment Final Submission
    document.getElementById('btn-confirm-booking')?.addEventListener('click', handleConfirmBooking);

    // Status Tracking Search Form
    const trackForm = document.getElementById('track-search-form');
    if (trackForm) {
      trackForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const input = document.getElementById('track-search-input');
        if (input && input.value.trim()) {
          await performStatusLookup(input.value.trim());
        }
      });
    }

    // Quick Sample Track Buttons
    document.querySelectorAll('.sample-ref-badge').forEach(badge => {
      badge.addEventListener('click', async (e) => {
        e.preventDefault();
        const code = badge.getAttribute('data-ref');
        const input = document.getElementById('track-search-input');
        if (input) input.value = code;
        await performStatusLookup(code);
      });
    });

    // Staff Portal Filters
    document.getElementById('staff-filter-status')?.addEventListener('change', (e) => {
      state.staffFilter.status = e.target.value;
      loadStaffAppointments();
    });
    document.getElementById('staff-filter-date')?.addEventListener('change', (e) => {
      state.staffFilter.date = e.target.value;
      loadStaffAppointments();
    });
    document.getElementById('staff-search-input')?.addEventListener('input', debounce((e) => {
      state.staffFilter.search = e.target.value;
      loadStaffAppointments();
    }, 300));

    // Staff Refresh
    document.getElementById('btn-refresh-staff')?.addEventListener('click', () => {
      loadStaffAppointments();
      showToast('Appointment list refreshed', 'info');
    });

    // Modal Close buttons
    document.querySelectorAll('[data-close-modal]').forEach(btn => {
      btn.addEventListener('click', () => {
        closeAllModals();
      });
    });

    // Reschedule Confirm
    document.getElementById('btn-confirm-reschedule')?.addEventListener('click', handleConfirmReschedule);

    // Cancel Confirm
    document.getElementById('btn-confirm-cancel')?.addEventListener('click', handleConfirmCancel);

    // Print button
    document.getElementById('btn-trigger-print')?.addEventListener('click', () => {
      window.print();
    });
  }

  function handleHashNavigation() {
    const hash = window.location.hash || '#book';
    if (hash === '#track') {
      showSection('status-section');
    } else if (hash === '#staff') {
      showSection('staff-section');
      loadStaffAppointments();
    } else {
      showSection('booking-section');
    }
  }

  function showSection(sectionId) {
    const bookingSection = document.getElementById('booking-section');
    const statusSection = document.getElementById('status-section');
    const staffSection = document.getElementById('staff-section');

    const navLinks = document.querySelectorAll('.main-nav-link');
    navLinks.forEach(link => link.classList.remove('text-blue-600', 'font-bold'));

    if (sectionId === 'status-section') {
      bookingSection?.classList.add('hidden');
      statusSection?.classList.remove('hidden');
      staffSection?.classList.add('hidden');
      document.getElementById('nav-track')?.classList.add('text-blue-600', 'font-bold');
      statusSection?.scrollIntoView({ behavior: 'smooth' });
    } else if (sectionId === 'staff-section') {
      bookingSection?.classList.add('hidden');
      statusSection?.classList.add('hidden');
      staffSection?.classList.remove('hidden');
      document.getElementById('nav-staff')?.classList.add('text-blue-600', 'font-bold');
      staffSection?.scrollIntoView({ behavior: 'smooth' });
    } else {
      bookingSection?.classList.remove('hidden');
      statusSection?.classList.add('hidden');
      staffSection?.classList.add('hidden');
      document.getElementById('nav-book')?.classList.add('text-blue-600', 'font-bold');
    }
  }

  // Render Department Filter Tabs
  function renderDepartmentTabs() {
    if (!deptTabs) return;
    const departments = ['All', ...new Set(state.specialists.map(s => s.department))];
    deptTabs.innerHTML = departments.map((dept, index) => {
      const activeClass = (dept.toLowerCase() === 'all')
        ? 'bg-blue-600 text-white shadow-sm'
        : 'bg-white text-slate-600 border border-slate-200 hover:border-blue-300 hover:text-blue-600';
      return `
        <button type="button" class="dept-tab-btn px-4 py-2 rounded-xl text-sm font-medium transition-all ${activeClass}" data-dept="${dept}">
          ${dept}
        </button>
      `;
    }).join('');

    deptTabs.querySelectorAll('.dept-tab-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        deptTabs.querySelectorAll('.dept-tab-btn').forEach(b => {
          b.className = 'dept-tab-btn px-4 py-2 rounded-xl text-sm font-medium transition-all bg-white text-slate-600 border border-slate-200 hover:border-blue-300 hover:text-blue-600';
        });
        btn.className = 'dept-tab-btn px-4 py-2 rounded-xl text-sm font-medium transition-all bg-blue-600 text-white shadow-sm';
        state.selectedDepartment = btn.getAttribute('data-dept');
        renderSpecialists();
      });
    });
  }

  // Render Specialists Cards
  function renderSpecialists() {
    if (!specialistsGrid) return;
    const filtered = state.selectedDepartment.toLowerCase() === 'all'
      ? state.specialists
      : state.specialists.filter(s => s.department.toLowerCase() === state.selectedDepartment.toLowerCase());

    if (filtered.length === 0) {
      specialistsGrid.innerHTML = `
        <div class="col-span-full text-center py-12 bg-white rounded-2xl border border-slate-200">
          <i class="fa-solid fa-user-doctor text-4xl text-slate-300 mb-3"></i>
          <p class="text-slate-600 font-medium">No doctors found in this department.</p>
        </div>
      `;
      return;
    }

    specialistsGrid.innerHTML = filtered.map(s => {
      const isSelected = state.selectedSpecialist && state.selectedSpecialist.id === s.id;
      return `
        <div class="specialist-card glass-card rounded-2xl p-5 border cursor-pointer transition-all glass-card-hover ${isSelected ? 'selected' : 'border-slate-200'}" data-id="${s.id}">
          <div class="flex items-start gap-4">
            <img src="${s.image_url}" alt="${s.name}" class="w-16 h-16 rounded-2xl object-cover border-2 border-blue-200 shadow-sm flex-shrink-0" />
            <div class="flex-1 min-w-0">
              <div class="flex items-center justify-between mb-1">
                <span class="inline-block px-2.5 py-0.5 rounded-full text-xs font-semibold bg-blue-100 text-blue-700">
                  ${s.department}
                </span>
                <span class="flex items-center text-xs font-bold text-amber-500">
                  <i class="fa-solid fa-star mr-1"></i>${s.rating}
                </span>
              </div>
              <h3 class="font-bold text-slate-900 text-base leading-tight truncate">${s.name}</h3>
              <p class="text-xs text-slate-500 truncate mb-2">${s.title}</p>
              
              <div class="flex items-center justify-between text-xs pt-2 border-t border-slate-100">
                <span class="text-slate-500"><i class="fa-solid fa-clock-rotate-left mr-1 text-blue-500"></i>${s.experience}</span>
                <span class="font-bold text-blue-600 text-sm">$${s.consultation_fee}</span>
              </div>
            </div>
          </div>
          <div class="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between">
            <span class="text-xs text-slate-400 flex items-center">
              <i class="fa-solid fa-location-dot mr-1 text-slate-400"></i>${s.room_number}
            </span>
            <span class="select-badge text-xs font-semibold ${isSelected ? 'text-blue-600 font-bold' : 'text-slate-400'}">
              ${isSelected ? '<i class="fa-solid fa-circle-check text-blue-600 mr-1"></i>Selected' : 'Select Specialist →'}
            </span>
          </div>
        </div>
      `;
    }).join('');

    // Attach click events
    specialistsGrid.querySelectorAll('.specialist-card').forEach(card => {
      card.addEventListener('click', () => {
        const id = parseInt(card.getAttribute('data-id'));
        state.selectedSpecialist = state.specialists.find(s => s.id === id);
        renderSpecialists();
        // Update summary preview in Step 1
        const docSummary = document.getElementById('step1-selected-doc-summary');
        if (docSummary) {
          docSummary.innerHTML = `
            <div class="flex items-center gap-3">
              <img src="${state.selectedSpecialist.image_url}" class="w-10 h-10 rounded-xl object-cover border border-blue-300">
              <div>
                <p class="text-xs text-blue-100 uppercase tracking-wider font-semibold">Selected Doctor</p>
                <p class="text-sm font-bold text-white">${state.selectedSpecialist.name} (${state.selectedSpecialist.department})</p>
              </div>
            </div>
          `;
          docSummary.classList.remove('hidden');
        }
      });
    });
  }

  // Quick Date Pills (Today, Tomorrow, Day+2, Day+3)
  function renderQuickDatePills() {
    if (!quickDatePills) return;
    const days = [
      { label: 'Today', offset: 0 },
      { label: 'Tomorrow', offset: 1 },
      { label: 'In 2 Days', offset: 2 },
      { label: 'In 3 Days', offset: 3 },
      { label: 'Next Week', offset: 7 }
    ];

    quickDatePills.innerHTML = days.map(d => {
      const dateStr = getDateOffsetString(d.offset);
      const isSelected = state.selectedDate === dateStr;
      return `
        <button type="button" class="quick-date-btn px-3 py-1.5 rounded-xl text-xs font-semibold transition-all ${isSelected ? 'bg-blue-600 text-white shadow-sm' : 'bg-slate-100 text-slate-600 hover:bg-blue-50 hover:text-blue-600'}" data-date="${dateStr}">
          ${d.label}
        </button>
      `;
    }).join('');

    quickDatePills.querySelectorAll('.quick-date-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        const date = btn.getAttribute('data-date');
        state.selectedDate = date;
        if (datePicker) datePicker.value = date;
        updateQuickDateActive();
        state.selectedSlot = null;
        loadAvailableSlots();
      });
    });
  }

  function updateQuickDateActive() {
    if (!quickDatePills) return;
    quickDatePills.querySelectorAll('.quick-date-btn').forEach(btn => {
      const d = btn.getAttribute('data-date');
      if (d === state.selectedDate) {
        btn.className = 'quick-date-btn px-3 py-1.5 rounded-xl text-xs font-semibold transition-all bg-blue-600 text-white shadow-sm';
      } else {
        btn.className = 'quick-date-btn px-3 py-1.5 rounded-xl text-xs font-semibold transition-all bg-slate-100 text-slate-600 hover:bg-blue-50 hover:text-blue-600';
      }
    });
  }

  // Load Time Slots
  async function loadAvailableSlots() {
    if (!state.selectedSpecialist || !state.selectedDate) return;

    // Show loading skeleton in slots
    [morningSlotsEl, afternoonSlotsEl, eveningSlotsEl].forEach(el => {
      if (el) el.innerHTML = `<div class="col-span-full py-4 text-center text-xs text-slate-400"><i class="fa-solid fa-spinner fa-spin mr-2 text-blue-500"></i>Checking slot availability...</div>`;
    });

    const slots = await window.apiClient.getSlots(state.selectedSpecialist.id, state.selectedDate);

    // Group slots into Morning, Afternoon, Evening
    const morning = slots.filter(s => s.time.includes('AM') && !s.time.startsWith('12'));
    const afternoon = slots.filter(s => s.time.includes('PM') && (s.time.startsWith('01') || s.time.startsWith('02') || s.time.startsWith('03') || s.time.startsWith('04')));
    const evening = slots.filter(s => s.time.includes('PM') && (s.time.startsWith('05') || s.time.startsWith('06') || s.time.startsWith('07')));

    renderSlotCategory(morningSlotsEl, morning);
    renderSlotCategory(afternoonSlotsEl, afternoon);
    renderSlotCategory(eveningSlotsEl, evening);

    updateSelectedSlotPreview();
  }

  function renderSlotCategory(container, slotList) {
    if (!container) return;
    if (slotList.length === 0) {
      container.innerHTML = `<p class="col-span-full text-xs text-slate-400 py-2">No slots configured in this window.</p>`;
      return;
    }

    container.innerHTML = slotList.map(s => {
      const isSelected = state.selectedSlot === s.time;
      const disabledAttr = !s.is_available ? 'disabled title="Slot already booked"' : '';
      const selectedClass = isSelected ? 'selected' : '';
      return `
        <button type="button" class="slot-btn py-2.5 px-3 rounded-xl text-xs font-medium bg-white text-slate-700 shadow-sm ${selectedClass}" data-time="${s.time}" ${disabledAttr}>
          ${s.time}
          ${!s.is_available ? '<span class="block text-[10px] text-rose-500 font-bold">Booked</span>' : ''}
        </button>
      `;
    }).join('');

    container.querySelectorAll('.slot-btn:not(:disabled)').forEach(btn => {
      btn.addEventListener('click', () => {
        document.querySelectorAll('.slot-btn').forEach(b => b.classList.remove('selected'));
        btn.classList.add('selected');
        state.selectedSlot = btn.getAttribute('data-time');
        updateSelectedSlotPreview();
      });
    });
  }

  function updateSelectedSlotPreview() {
    const previewEl = document.getElementById('selected-datetime-preview');
    if (!previewEl) return;
    if (state.selectedSlot) {
      previewEl.innerHTML = `
        <div class="flex items-center justify-between p-3 rounded-xl bg-blue-50 border border-blue-200">
          <div class="flex items-center gap-2">
            <i class="fa-solid fa-calendar-check text-blue-600 text-lg"></i>
            <div>
              <p class="text-xs text-blue-600 font-semibold uppercase">Chosen Schedule</p>
              <p class="text-sm font-bold text-slate-800">${formatReadableDate(state.selectedDate)} at ${state.selectedSlot}</p>
            </div>
          </div>
          <span class="px-2.5 py-1 rounded-full text-xs font-bold bg-blue-600 text-white">Confirmed Slot</span>
        </div>
      `;
      previewEl.classList.remove('hidden');
    } else {
      previewEl.classList.add('hidden');
    }
  }

  // Wizard Step Navigation
  function goToStep(stepNumber) {
    state.currentStep = stepNumber;
    stepPanels.forEach(panel => {
      const pStep = parseInt(panel.getAttribute('data-step'));
      if (pStep === stepNumber) {
        panel.classList.remove('hidden');
      } else {
        panel.classList.add('hidden');
      }
    });

    stepIndicators.forEach(indicator => {
      const iStep = parseInt(indicator.getAttribute('data-step'));
      const circle = indicator.querySelector('.step-circle');
      const label = indicator.querySelector('.step-label');

      if (iStep < stepNumber) {
        // Completed step
        circle.className = 'step-circle w-8 h-8 rounded-full flex items-center justify-center font-bold text-xs bg-emerald-500 text-white shadow-sm';
        circle.innerHTML = '<i class="fa-solid fa-check"></i>';
        label?.classList.remove('text-slate-400');
        label?.classList.add('text-slate-700', 'font-semibold');
      } else if (iStep === stepNumber) {
        // Active step
        circle.className = 'step-circle w-8 h-8 rounded-full flex items-center justify-center font-bold text-xs bg-blue-600 text-white ring-4 ring-blue-100 shadow-md';
        circle.innerHTML = `${iStep}`;
        label?.classList.remove('text-slate-400');
        label?.classList.add('text-blue-600', 'font-bold');
      } else {
        // Pending step
        circle.className = 'step-circle w-8 h-8 rounded-full flex items-center justify-center font-bold text-xs bg-slate-100 text-slate-400 border border-slate-200';
        circle.innerHTML = `${iStep}`;
        label?.classList.remove('text-blue-600', 'font-bold', 'text-slate-700');
        label?.classList.add('text-slate-400');
      }
    });

    // Scroll to wizard top
    document.getElementById('booking-wizard-card')?.scrollIntoView({ behavior: 'smooth', block: 'start' });
  }

  // Populate Step 4 Review Summary
  function populateReviewSummary() {
    const s = state.selectedSpecialist;
    const name = document.getElementById('patient-name')?.value || '';
    const email = document.getElementById('patient-email')?.value || '';
    const phone = document.getElementById('patient-phone')?.value || '';
    const consultType = document.querySelector('input[name="consultation-type"]:checked')?.value || 'In-Person Clinic Visit';
    const symptoms = document.getElementById('patient-symptoms')?.value || 'General checkup';

    const reviewDoc = document.getElementById('review-doc-card');
    if (reviewDoc && s) {
      reviewDoc.innerHTML = `
        <div class="flex items-center gap-4">
          <img src="${s.image_url}" class="w-16 h-16 rounded-2xl object-cover border-2 border-blue-200 shadow-sm">
          <div>
            <span class="inline-block px-2.5 py-0.5 rounded-full text-xs font-semibold bg-blue-100 text-blue-700 mb-1">${s.department}</span>
            <h4 class="font-bold text-slate-900 text-base">${s.name}</h4>
            <p class="text-xs text-slate-500">${s.title}</p>
            <p class="text-xs text-slate-400 mt-1"><i class="fa-solid fa-location-dot mr-1"></i>${s.room_number}</p>
          </div>
        </div>
      `;
    }

    const reviewDetails = document.getElementById('review-details-card');
    if (reviewDetails) {
      reviewDetails.innerHTML = `
        <div class="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
          <div class="p-3 bg-slate-50 rounded-xl border border-slate-100">
            <p class="text-xs text-slate-400 font-semibold uppercase">Appointment Date & Time</p>
            <p class="font-bold text-blue-700 text-base mt-0.5"><i class="fa-regular fa-calendar mr-1.5"></i>${formatReadableDate(state.selectedDate)}</p>
            <p class="font-semibold text-slate-700 text-sm"><i class="fa-regular fa-clock mr-1.5"></i>${state.selectedSlot}</p>
          </div>
          <div class="p-3 bg-slate-50 rounded-xl border border-slate-100">
            <p class="text-xs text-slate-400 font-semibold uppercase">Consultation Mode</p>
            <p class="font-bold text-slate-800 text-base mt-0.5"><i class="fa-solid fa-hospital-user mr-1.5 text-blue-600"></i>${consultType}</p>
            <p class="text-xs text-slate-500 mt-1">Status on submit: <span class="text-emerald-600 font-semibold">Instant Confirmed</span></p>
          </div>
          <div class="p-3 bg-slate-50 rounded-xl border border-slate-100 md:col-span-2">
            <p class="text-xs text-slate-400 font-semibold uppercase">Patient Information</p>
            <div class="flex flex-wrap items-center gap-x-6 gap-y-1 mt-1 text-slate-800">
              <span class="font-bold"><i class="fa-regular fa-user mr-1 text-slate-400"></i>${name}</span>
              <span><i class="fa-regular fa-envelope mr-1 text-slate-400"></i>${email}</span>
              <span><i class="fa-solid fa-phone mr-1 text-slate-400"></i>${phone}</span>
            </div>
            ${symptoms ? `<p class="text-xs text-slate-500 mt-2 italic"><span class="font-semibold not-italic text-slate-700">Reason / Notes:</span> ${symptoms}</p>` : ''}
          </div>
        </div>
      `;
    }

    const feeAmount = document.getElementById('review-fee-amount');
    if (feeAmount && s) {
      feeAmount.innerText = `$${s.consultation_fee}`;
    }
  }

  // Handle Confirm Booking
  async function handleConfirmBooking() {
    const btn = document.getElementById('btn-confirm-booking');
    const originalText = btn.innerHTML;
    btn.disabled = true;
    btn.innerHTML = `<i class="fa-solid fa-spinner fa-spin mr-2"></i>Processing Booking...`;

    try {
      const payload = {
        patient_name: document.getElementById('patient-name').value.trim(),
        patient_email: document.getElementById('patient-email').value.trim(),
        patient_phone: document.getElementById('patient-phone').value.trim(),
        specialist_id: state.selectedSpecialist.id,
        service_name: `${state.selectedSpecialist.department} Consultation`,
        appointment_date: state.selectedDate,
        appointment_time: state.selectedSlot,
        consultation_type: document.querySelector('input[name="consultation-type"]:checked')?.value || 'In-Person Clinic Visit',
        symptoms: document.getElementById('patient-symptoms')?.value.trim() || ''
      };

      const res = await window.apiClient.bookAppointment(payload);
      state.bookingResult = res.appointment;

      // Show Step 5: Success Pass
      renderSuccessPass(res.appointment);
      goToStep(5);
      showToast('Appointment successfully confirmed!', 'success');

    } catch (err) {
      console.error(err);
      showToast(err.message || 'Error completing booking. Please try again.', 'error');
      btn.disabled = false;
      btn.innerHTML = originalText;
    }
  }

  // Render Step 5 Success Pass
  function renderSuccessPass(apt) {
    const container = document.getElementById('success-pass-content');
    if (!container) return;

    container.innerHTML = `
      <div class="text-center mb-6">
        <div class="inline-flex items-center justify-center w-16 h-16 rounded-full bg-emerald-100 text-emerald-600 mb-3 shadow-inner">
          <i class="fa-solid fa-check text-2xl"></i>
        </div>
        <h3 class="text-2xl font-black text-slate-900">Booking Confirmed!</h3>
        <p class="text-slate-500 text-sm mt-1">A confirmation has been recorded and scheduled in our clinic system.</p>
      </div>

      <div class="p-6 bg-gradient-to-br from-blue-900 via-blue-800 to-indigo-900 rounded-2xl text-white shadow-xl relative overflow-hidden mb-6">
        <div class="absolute -right-10 -bottom-10 w-40 h-40 bg-blue-500/20 rounded-full blur-2xl pointer-events-none"></div>
        <div class="flex items-center justify-between border-b border-white/10 pb-4 mb-4">
          <div class="flex items-center gap-2">
            <span class="w-8 h-8 rounded-lg bg-white/20 flex items-center justify-center text-white font-bold text-sm">
              <i class="fa-solid fa-hospital"></i>
            </span>
            <span class="font-bold text-sm tracking-wide">ApexCare Digital Pass</span>
          </div>
          <span class="px-3 py-1 rounded-full text-xs font-bold bg-emerald-500 text-white shadow-sm flex items-center gap-1">
            <i class="fa-solid fa-circle-check text-[10px]"></i> ${apt.status}
          </span>
        </div>

        <div class="mb-4">
          <p class="text-xs text-blue-200 uppercase tracking-wider font-semibold">Booking Reference Code</p>
          <div class="flex items-center gap-3 mt-1">
            <span class="text-2xl font-black tracking-widest text-white font-mono">${apt.booking_reference}</span>
            <button type="button" class="btn-copy-ref px-2.5 py-1 rounded-lg bg-white/15 hover:bg-white/25 text-xs text-white transition-all" data-code="${apt.booking_reference}">
              <i class="fa-regular fa-copy mr-1"></i>Copy
            </button>
          </div>
        </div>

        <div class="grid grid-cols-2 gap-4 text-xs pt-4 border-t border-white/10">
          <div>
            <p class="text-blue-200 uppercase font-semibold">Patient</p>
            <p class="font-bold text-sm text-white mt-0.5">${apt.patient_name}</p>
          </div>
          <div>
            <p class="text-blue-200 uppercase font-semibold">Specialist</p>
            <p class="font-bold text-sm text-white mt-0.5">${apt.specialist_name}</p>
          </div>
          <div>
            <p class="text-blue-200 uppercase font-semibold">Date & Time</p>
            <p class="font-bold text-sm text-white mt-0.5">${apt.appointment_date} at ${apt.appointment_time}</p>
          </div>
          <div>
            <p class="text-blue-200 uppercase font-semibold">Location / Mode</p>
            <p class="font-bold text-sm text-white mt-0.5">${apt.consultation_type}</p>
          </div>
        </div>
      </div>

      <div class="flex flex-wrap items-center justify-center gap-3">
        <button type="button" id="btn-print-pass" class="px-5 py-2.5 rounded-xl bg-slate-900 hover:bg-black text-white text-sm font-semibold shadow-sm transition-all flex items-center gap-2">
          <i class="fa-solid fa-print"></i>Print / Save PDF Slip
        </button>
        <button type="button" id="btn-calendar-add" class="px-5 py-2.5 rounded-xl bg-blue-50 hover:bg-blue-100 text-blue-700 border border-blue-200 text-sm font-semibold transition-all flex items-center gap-2">
          <i class="fa-regular fa-calendar-plus"></i>Add to Calendar
        </button>
        <button type="button" id="btn-view-status-now" class="px-5 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-sm font-semibold shadow-md transition-all flex items-center gap-2">
          <i class="fa-solid fa-magnifying-glass"></i>Track Status
        </button>
      </div>
    `;

    // Copy event
    container.querySelector('.btn-copy-ref')?.addEventListener('click', () => {
      navigator.clipboard.writeText(apt.booking_reference);
      showToast('Booking reference copied to clipboard!', 'info');
    });

    // Print Pass modal
    container.querySelector('#btn-print-pass')?.addEventListener('click', () => {
      openPrintModal(apt);
    });

    // Add to Google Calendar
    container.querySelector('#btn-calendar-add')?.addEventListener('click', () => {
      openGoogleCalendar(apt);
    });

    // View Status Now
    container.querySelector('#btn-view-status-now')?.addEventListener('click', () => {
      window.location.hash = '#track';
      const input = document.getElementById('track-search-input');
      if (input) input.value = apt.booking_reference;
      performStatusLookup(apt.booking_reference);
    });
  }

  // Status Lookup Logic
  async function performStatusLookup(query) {
    const resultsContainer = document.getElementById('track-results-container');
    if (!resultsContainer) return;

    resultsContainer.innerHTML = `
      <div class="text-center py-12">
        <i class="fa-solid fa-circle-notch fa-spin text-3xl text-blue-600 mb-3"></i>
        <p class="text-slate-600 font-medium">Looking up booking records...</p>
      </div>
    `;
    resultsContainer.classList.remove('hidden');

    try {
      const appointments = await window.apiClient.trackAppointment(query);
      if (appointments.length === 0) {
        resultsContainer.innerHTML = `
          <div class="p-8 text-center bg-white rounded-2xl border border-slate-200">
            <div class="w-14 h-14 rounded-full bg-slate-100 text-slate-400 flex items-center justify-center mx-auto mb-3 text-xl">
              <i class="fa-solid fa-file-circle-question"></i>
            </div>
            <h4 class="text-lg font-bold text-slate-800">No Booking Found</h4>
            <p class="text-slate-500 text-sm mt-1 max-w-md mx-auto">We couldn't locate any appointment matching "${escapeHtml(query)}". Please double-check your Booking Reference Code or telephone number.</p>
            <div class="mt-4 flex justify-center gap-2">
              <button type="button" class="sample-ref-badge px-3 py-1.5 rounded-lg bg-blue-50 text-blue-700 text-xs font-semibold hover:bg-blue-100" data-ref="APT-2026-101">Try APT-2026-101</button>
              <button type="button" class="sample-ref-badge px-3 py-1.5 rounded-lg bg-blue-50 text-blue-700 text-xs font-semibold hover:bg-blue-100" data-ref="APT-2026-102">Try APT-2026-102</button>
            </div>
          </div>
        `;
        // Re-attach sample click
        resultsContainer.querySelectorAll('.sample-ref-badge').forEach(b => {
          b.addEventListener('click', () => performStatusLookup(b.getAttribute('data-ref')));
        });
        return;
      }

      // Render appointments cards
      resultsContainer.innerHTML = appointments.map(apt => renderStatusCardHtml(apt)).join('');

      // Attach actions for each card
      appointments.forEach(apt => {
        const card = document.getElementById(`apt-card-${apt.booking_reference}`);
        if (!card) return;

        // Copy button
        card.querySelector('.btn-copy')?.addEventListener('click', () => {
          navigator.clipboard.writeText(apt.booking_reference);
          showToast(`Copied ${apt.booking_reference}`, 'info');
        });

        // Reschedule button
        card.querySelector('.btn-reschedule')?.addEventListener('click', () => {
          openRescheduleModal(apt);
        });

        // Cancel button
        card.querySelector('.btn-cancel')?.addEventListener('click', () => {
          openCancelModal(apt);
        });

        // Print slip button
        card.querySelector('.btn-print')?.addEventListener('click', () => {
          openPrintModal(apt);
        });

        // Calendar button
        card.querySelector('.btn-calendar')?.addEventListener('click', () => {
          openGoogleCalendar(apt);
        });
      });

    } catch (e) {
      console.error(e);
      resultsContainer.innerHTML = `
        <div class="p-6 text-center bg-rose-50 text-rose-700 rounded-2xl border border-rose-200">
          <p class="font-bold">Error loading status</p>
          <p class="text-xs mt-1">${e.message}</p>
        </div>
      `;
    }
  }

  function renderStatusCardHtml(apt) {
    const statusCfg = getStatusConfig(apt.status);
    const isPast = new Date(apt.appointment_date) < new Date(getTodayDateString());
    const canModify = apt.status !== 'Cancelled' && apt.status !== 'Completed';

    return `
      <div id="apt-card-${apt.booking_reference}" class="glass-card rounded-2xl p-6 border border-slate-200 shadow-md mb-6 transition-all">
        <!-- Top Row: Ref & Status -->
        <div class="flex flex-wrap items-center justify-between gap-3 pb-4 border-b border-slate-100">
          <div class="flex items-center gap-3">
            <span class="w-10 h-10 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center font-bold text-lg">
              <i class="fa-regular fa-calendar-check"></i>
            </span>
            <div>
              <p class="text-xs text-slate-400 font-semibold uppercase">Booking Reference</p>
              <div class="flex items-center gap-2">
                <span class="text-lg font-black text-slate-900 font-mono">${apt.booking_reference}</span>
                <button type="button" class="btn-copy text-xs text-slate-400 hover:text-blue-600 transition-colors" title="Copy Reference">
                  <i class="fa-regular fa-copy"></i>
                </button>
              </div>
            </div>
          </div>

          <div class="flex items-center gap-2">
            <span class="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-bold ${statusCfg.badgeClass} border shadow-sm">
              <i class="${statusCfg.icon}"></i>
              ${apt.status}
            </span>
          </div>
        </div>

        <!-- Timeline Progress Graphic -->
        <div class="py-5 px-2">
          <div class="flex items-center justify-between relative max-w-xl mx-auto">
            ${renderTimelineSteps(apt.status)}
          </div>
        </div>

        <!-- Appointment Details Grid -->
        <div class="grid grid-cols-1 md:grid-cols-3 gap-4 p-4 bg-slate-50 rounded-2xl border border-slate-100 text-sm mb-5">
          <!-- Specialist Column -->
          <div class="flex items-start gap-3">
            <img src="${apt.specialist_image || 'https://images.unsplash.com/photo-1559839734-2b71ea197ec2?auto=format&fit=crop&q=80&w=300'}" class="w-12 h-12 rounded-xl object-cover border border-blue-200">
            <div>
              <p class="text-xs text-slate-400 uppercase font-semibold">Doctor / Specialist</p>
              <p class="font-bold text-slate-900">${apt.specialist_name}</p>
              <p class="text-xs text-blue-600 font-medium">${apt.department}</p>
              <p class="text-xs text-slate-500 mt-1"><i class="fa-solid fa-location-dot mr-1"></i>${apt.room_number || 'Room 101'}</p>
            </div>
          </div>

          <!-- Schedule Column -->
          <div>
            <p class="text-xs text-slate-400 uppercase font-semibold">Scheduled Time</p>
            <p class="font-bold text-slate-900 text-base mt-0.5"><i class="fa-regular fa-calendar text-blue-600 mr-1.5"></i>${formatReadableDate(apt.appointment_date)}</p>
            <p class="font-semibold text-slate-700 text-sm mt-0.5"><i class="fa-regular fa-clock text-blue-600 mr-1.5"></i>${apt.appointment_time}</p>
            <span class="inline-block mt-1 px-2 py-0.5 bg-blue-100/70 text-blue-800 text-[11px] rounded-md font-medium">${apt.consultation_type}</span>
          </div>

          <!-- Patient Column -->
          <div>
            <p class="text-xs text-slate-400 uppercase font-semibold">Patient Information</p>
            <p class="font-bold text-slate-900">${apt.patient_name}</p>
            <p class="text-xs text-slate-500"><i class="fa-regular fa-envelope mr-1"></i>${apt.patient_email}</p>
            <p class="text-xs text-slate-500"><i class="fa-solid fa-phone mr-1"></i>${apt.patient_phone}</p>
            ${apt.symptoms ? `<p class="text-xs text-slate-600 mt-1 italic line-clamp-1" title="${escapeHtml(apt.symptoms)}">"${apt.symptoms}"</p>` : ''}
          </div>
        </div>

        <!-- Action Bar -->
        <div class="flex flex-wrap items-center justify-between gap-3 pt-3 border-t border-slate-100">
          <div class="flex items-center gap-2 text-xs text-slate-400">
            <i class="fa-regular fa-clock"></i> Booked on ${new Date(apt.created_at).toLocaleDateString()}
          </div>

          <div class="flex items-center gap-2">
            <button type="button" class="btn-calendar px-3 py-1.5 rounded-xl border border-slate-200 text-slate-700 hover:bg-slate-50 text-xs font-semibold transition-all">
              <i class="fa-regular fa-calendar mr-1.5 text-blue-600"></i>Calendar
            </button>
            <button type="button" class="btn-print px-3 py-1.5 rounded-xl border border-slate-200 text-slate-700 hover:bg-slate-50 text-xs font-semibold transition-all">
              <i class="fa-solid fa-print mr-1.5 text-slate-600"></i>Print Slip
            </button>

            ${canModify ? `
              <button type="button" class="btn-reschedule px-3 py-1.5 rounded-xl bg-blue-50 text-blue-700 hover:bg-blue-100 border border-blue-200 text-xs font-semibold transition-all">
                <i class="fa-solid fa-arrows-rotate mr-1.5"></i>Reschedule
              </button>
              <button type="button" class="btn-cancel px-3 py-1.5 rounded-xl bg-rose-50 text-rose-700 hover:bg-rose-100 border border-rose-200 text-xs font-semibold transition-all">
                <i class="fa-solid fa-ban mr-1.5"></i>Cancel
              </button>
            ` : ''}
          </div>
        </div>
      </div>
    `;
  }

  function renderTimelineSteps(status) {
    const steps = [
      { key: 'booked', label: 'Booked' },
      { key: 'confirmed', label: 'Confirmed' },
      { key: 'ready', label: 'Clinic Check-in' },
      { key: 'completed', label: 'Consulted' }
    ];

    let activeIndex = 1; // Confirmed
    if (status === 'Pending Approval') activeIndex = 0;
    if (status === 'Confirmed' || status === 'Rescheduled') activeIndex = 1;
    if (status === 'In Progress') activeIndex = 2;
    if (status === 'Completed') activeIndex = 3;
    if (status === 'Cancelled') {
      return `
        <div class="w-full text-center py-2 bg-rose-50 border border-rose-200 rounded-xl text-rose-700 font-semibold text-xs">
          <i class="fa-solid fa-triangle-exclamation mr-1.5"></i> This appointment has been cancelled.
        </div>
      `;
    }

    return steps.map((s, idx) => {
      const isDone = idx <= activeIndex;
      const isCurrent = idx === activeIndex;
      const circleClass = isDone
        ? 'bg-blue-600 text-white ring-4 ring-blue-100'
        : 'bg-slate-200 text-slate-400';

      return `
        <div class="flex-1 flex flex-col items-center relative z-10">
          <div class="w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold transition-all ${circleClass}">
            ${isDone ? '<i class="fa-solid fa-check text-[10px]"></i>' : idx + 1}
          </div>
          <span class="text-[11px] font-semibold mt-1.5 ${isCurrent ? 'text-blue-600 font-bold' : isDone ? 'text-slate-700' : 'text-slate-400'}">${s.label}</span>
        </div>
      `;
    }).join('');
  }

  function getStatusConfig(status) {
    switch (status) {
      case 'Confirmed':
      case 'Rescheduled':
        return { badgeClass: 'bg-emerald-50 text-emerald-700 border-emerald-200', icon: 'fa-solid fa-circle-check text-emerald-500' };
      case 'Pending Approval':
        return { badgeClass: 'bg-amber-50 text-amber-700 border-amber-200', icon: 'fa-solid fa-clock text-amber-500' };
      case 'Completed':
        return { badgeClass: 'bg-blue-50 text-blue-700 border-blue-200', icon: 'fa-solid fa-clipboard-check text-blue-500' };
      case 'Cancelled':
        return { badgeClass: 'bg-rose-50 text-rose-700 border-rose-200', icon: 'fa-solid fa-circle-xmark text-rose-500' };
      default:
        return { badgeClass: 'bg-slate-50 text-slate-700 border-slate-200', icon: 'fa-solid fa-circle-info' };
    }
  }

  // Reschedule Modal
  async function openRescheduleModal(apt) {
    state.activeTrackingAppointment = apt;
    const modal = document.getElementById('reschedule-modal');
    if (!modal) return;

    document.getElementById('reschedule-ref-text').innerText = apt.booking_reference;
    document.getElementById('reschedule-doc-text').innerText = `${apt.specialist_name} (${apt.department})`;
    
    const dateInput = document.getElementById('reschedule-date');
    dateInput.min = getTodayDateString();
    dateInput.value = apt.appointment_date;

    await loadRescheduleSlots(apt.specialist_id, dateInput.value, apt.appointment_time);

    dateInput.onchange = async () => {
      await loadRescheduleSlots(apt.specialist_id, dateInput.value);
    };

    modal.classList.remove('hidden');
  }

  async function loadRescheduleSlots(specialistId, dateStr, currentSlot = null) {
    const container = document.getElementById('reschedule-slots-grid');
    if (!container) return;
    container.innerHTML = `<div class="col-span-full py-4 text-center text-xs text-slate-400"><i class="fa-solid fa-spinner fa-spin mr-2"></i>Loading slots...</div>`;

    const slots = await window.apiClient.getSlots(specialistId, dateStr);
    container.innerHTML = slots.map(s => {
      const isSelected = currentSlot && s.time === currentSlot;
      const disabled = !s.is_available && s.time !== currentSlot ? 'disabled' : '';
      return `
        <button type="button" class="reschedule-slot-btn py-2 px-2.5 rounded-xl text-xs font-medium border ${isSelected ? 'bg-blue-600 text-white border-blue-600' : 'bg-white text-slate-700 border-slate-200 hover:border-blue-400'} ${disabled ? 'opacity-40 cursor-not-allowed bg-slate-100' : ''}" data-time="${s.time}" ${disabled}>
          ${s.time}
        </button>
      `;
    }).join('');

    container.querySelectorAll('.reschedule-slot-btn:not([disabled])').forEach(btn => {
      btn.addEventListener('click', () => {
        container.querySelectorAll('.reschedule-slot-btn').forEach(b => {
          b.className = 'reschedule-slot-btn py-2 px-2.5 rounded-xl text-xs font-medium border bg-white text-slate-700 border-slate-200 hover:border-blue-400';
        });
        btn.className = 'reschedule-slot-btn py-2 px-2.5 rounded-xl text-xs font-medium border bg-blue-600 text-white border-blue-600 shadow-sm';
        btn.setAttribute('data-selected', 'true');
      });
    });
  }

  async function handleConfirmReschedule() {
    const apt = state.activeTrackingAppointment;
    if (!apt) return;

    const newDate = document.getElementById('reschedule-date').value;
    const selectedBtn = document.querySelector('.reschedule-slot-btn[data-selected="true"]');
    if (!selectedBtn) {
      showToast('Please pick a new time slot.', 'warning');
      return;
    }
    const newTime = selectedBtn.getAttribute('data-time');

    try {
      const res = await window.apiClient.reschedule(apt.booking_reference, newDate, newTime);
      showToast('Appointment successfully rescheduled!', 'success');
      closeAllModals();
      await performStatusLookup(apt.booking_reference);
    } catch (err) {
      showToast(err.message || 'Failed to reschedule', 'error');
    }
  }

  // Cancel Modal
  function openCancelModal(apt) {
    state.activeTrackingAppointment = apt;
    const modal = document.getElementById('cancel-modal');
    if (!modal) return;
    document.getElementById('cancel-ref-text').innerText = apt.booking_reference;
    document.getElementById('cancel-date-text').innerText = `${apt.appointment_date} at ${apt.appointment_time}`;
    modal.classList.remove('hidden');
  }

  async function handleConfirmCancel() {
    const apt = state.activeTrackingAppointment;
    if (!apt) return;

    try {
      await window.apiClient.updateStatus(apt.booking_reference, 'Cancelled');
      showToast(`Appointment ${apt.booking_reference} has been cancelled.`, 'info');
      closeAllModals();
      await performStatusLookup(apt.booking_reference);
    } catch (err) {
      showToast(err.message || 'Failed to cancel appointment', 'error');
    }
  }

  // Print Slip Modal
  function openPrintModal(apt) {
    const modal = document.getElementById('print-modal');
    const container = document.getElementById('print-slip-details');
    if (!modal || !container) return;

    container.innerHTML = `
      <div class="border-2 border-blue-600 p-6 rounded-2xl bg-white shadow-sm text-slate-800">
        <div class="flex items-center justify-between border-b pb-4 mb-4 border-slate-200">
          <div class="flex items-center gap-2">
            <span class="w-10 h-10 rounded-xl bg-blue-600 text-white flex items-center justify-center font-bold text-lg">
              <i class="fa-solid fa-hospital"></i>
            </span>
            <div>
              <h3 class="text-xl font-black text-slate-900 tracking-tight">ApexCare Medical Center</h3>
              <p class="text-xs text-slate-500">Official Digital Appointment Pass</p>
            </div>
          </div>
          <div class="text-right">
            <span class="inline-block px-3 py-1 rounded-full text-xs font-bold bg-blue-100 text-blue-800">${apt.status}</span>
            <p class="text-xs text-slate-400 mt-1">Ref: <strong class="text-slate-800 font-mono">${apt.booking_reference}</strong></p>
          </div>
        </div>

        <div class="grid grid-cols-2 gap-4 text-xs mb-6">
          <div class="p-3 bg-slate-50 rounded-xl">
            <p class="text-slate-400 uppercase font-semibold">Patient Name</p>
            <p class="font-bold text-sm text-slate-900 mt-0.5">${apt.patient_name}</p>
            <p class="text-slate-500 mt-1">${apt.patient_phone} • ${apt.patient_email}</p>
          </div>
          <div class="p-3 bg-slate-50 rounded-xl">
            <p class="text-slate-400 uppercase font-semibold">Specialist</p>
            <p class="font-bold text-sm text-slate-900 mt-0.5">${apt.specialist_name}</p>
            <p class="text-slate-500 mt-1">${apt.department} • ${apt.room_number || 'Room 101'}</p>
          </div>
          <div class="p-3 bg-blue-50/60 rounded-xl">
            <p class="text-blue-700 uppercase font-semibold">Date & Time</p>
            <p class="font-bold text-sm text-blue-900 mt-0.5">${formatReadableDate(apt.appointment_date)}</p>
            <p class="font-semibold text-blue-800">${apt.appointment_time}</p>
          </div>
          <div class="p-3 bg-slate-50 rounded-xl">
            <p class="text-slate-400 uppercase font-semibold">Type & Fee</p>
            <p class="font-bold text-sm text-slate-900 mt-0.5">${apt.consultation_type}</p>
            <p class="text-slate-600 mt-1">Fee: <strong>$${apt.consultation_fee || 100}</strong> (Pay at clinic/online)</p>
          </div>
        </div>

        <!-- Simulated QR Code -->
        <div class="flex items-center justify-between p-4 bg-slate-50 rounded-xl border border-slate-200">
          <div class="flex items-center gap-3">
            <div class="w-16 h-16 bg-white p-1 rounded-lg border border-slate-300 flex items-center justify-center font-mono text-[9px] text-center leading-tight">
              <i class="fa-solid fa-qrcode text-4xl text-slate-800"></i>
            </div>
            <div>
              <p class="text-xs font-bold text-slate-800">Fast Check-in QR</p>
              <p class="text-[11px] text-slate-500">Scan at Reception Kiosk upon arrival</p>
            </div>
          </div>
          <div class="text-right text-[11px] text-slate-400">
            <p>Please arrive 10 min early.</p>
            <p>Emergency: +1 (800) 555-CARE</p>
          </div>
        </div>
      </div>
    `;

    modal.classList.remove('hidden');
  }

  // Google Calendar Link generator
  function openGoogleCalendar(apt) {
    const title = encodeURIComponent(`Medical Appointment: ${apt.specialist_name} (${apt.department})`);
    const details = encodeURIComponent(`ApexCare Appointment Pass\nReference: ${apt.booking_reference}\nDoctor: ${apt.specialist_name}\nType: ${apt.consultation_type}\nLocation: ${apt.room_number || 'ApexCare Clinic'}`);
    const location = encodeURIComponent(`ApexCare Medical Center, ${apt.room_number || 'Room 101'}`);
    
    // Parse date and time into YYYYMMDDTHHMMSS
    const dateFormatted = apt.appointment_date.replace(/-/g, '');
    const gcalUrl = `https://calendar.google.com/calendar/render?action=TEMPLATE&text=${title}&details=${details}&location=${location}`;
    window.open(gcalUrl, '_blank');
  }

  // Staff Portal
  async function loadStaffAppointments() {
    const tableBody = document.getElementById('staff-appointments-table');
    if (!tableBody) return;

    tableBody.innerHTML = `
      <tr>
        <td colspan="7" class="py-8 text-center text-slate-400 text-xs">
          <i class="fa-solid fa-spinner fa-spin mr-2"></i>Loading appointment records...
        </td>
      </tr>
    `;

    try {
      const list = await window.apiClient.getAllAppointments(state.staffFilter);
      updateStaffMetrics(list);

      if (list.length === 0) {
        tableBody.innerHTML = `
          <tr>
            <td colspan="7" class="py-8 text-center text-slate-400 text-xs">
              No appointments matching the selected filters.
            </td>
          </tr>
        `;
        return;
      }

      tableBody.innerHTML = list.map(apt => {
        const cfg = getStatusConfig(apt.status);
        return `
          <tr class="hover:bg-slate-50/70 border-b border-slate-100 transition-colors">
            <td class="py-3 px-4 font-mono font-bold text-xs text-blue-700">
              ${apt.booking_reference}
            </td>
            <td class="py-3 px-4">
              <p class="font-bold text-slate-900 text-xs">${escapeHtml(apt.patient_name)}</p>
              <p class="text-[11px] text-slate-400">${escapeHtml(apt.patient_phone)}</p>
            </td>
            <td class="py-3 px-4">
              <p class="font-semibold text-slate-800 text-xs">${escapeHtml(apt.specialist_name)}</p>
              <p class="text-[11px] text-blue-600">${escapeHtml(apt.department)}</p>
            </td>
            <td class="py-3 px-4 text-xs text-slate-700">
              <span class="font-medium">${apt.appointment_date}</span>
              <span class="text-slate-400 block text-[11px]">${apt.appointment_time}</span>
            </td>
            <td class="py-3 px-4 text-xs text-slate-600">
              ${apt.consultation_type}
            </td>
            <td class="py-3 px-4">
              <span class="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-bold ${cfg.badgeClass}">
                <i class="${cfg.icon} text-[9px]"></i>${apt.status}
              </span>
            </td>
            <td class="py-3 px-4 text-right">
              <div class="inline-flex items-center gap-1">
                ${apt.status === 'Pending Approval' ? `
                  <button type="button" class="btn-staff-approve px-2 py-1 rounded bg-emerald-50 text-emerald-700 hover:bg-emerald-100 text-xs font-semibold" data-ref="${apt.booking_reference}" title="Confirm Appointment">
                    Approve
                  </button>
                ` : ''}
                ${apt.status === 'Confirmed' ? `
                  <button type="button" class="btn-staff-complete px-2 py-1 rounded bg-blue-50 text-blue-700 hover:bg-blue-100 text-xs font-semibold" data-ref="${apt.booking_reference}" title="Mark Consultation Completed">
                    Complete
                  </button>
                ` : ''}
                ${apt.status !== 'Cancelled' ? `
                  <button type="button" class="btn-staff-cancel px-2 py-1 rounded bg-rose-50 text-rose-700 hover:bg-rose-100 text-xs font-semibold" data-ref="${apt.booking_reference}" title="Cancel">
                    Cancel
                  </button>
                ` : ''}
              </div>
            </td>
          </tr>
        `;
      }).join('');

      // Attach staff table actions
      tableBody.querySelectorAll('.btn-staff-approve').forEach(b => {
        b.addEventListener('click', async () => {
          const ref = b.getAttribute('data-ref');
          await window.apiClient.updateStatus(ref, 'Confirmed');
          showToast(`Appointment ${ref} confirmed`, 'success');
          loadStaffAppointments();
        });
      });

      tableBody.querySelectorAll('.btn-staff-complete').forEach(b => {
        b.addEventListener('click', async () => {
          const ref = b.getAttribute('data-ref');
          await window.apiClient.updateStatus(ref, 'Completed');
          showToast(`Appointment ${ref} marked completed`, 'info');
          loadStaffAppointments();
        });
      });

      tableBody.querySelectorAll('.btn-staff-cancel').forEach(b => {
        b.addEventListener('click', async () => {
          const ref = b.getAttribute('data-ref');
          await window.apiClient.updateStatus(ref, 'Cancelled');
          showToast(`Appointment ${ref} cancelled`, 'info');
          loadStaffAppointments();
        });
      });

    } catch (e) {
      console.error(e);
      tableBody.innerHTML = `<tr><td colspan="7" class="py-6 text-center text-rose-600 text-xs font-semibold">Failed to load appointments</td></tr>`;
    }
  }

  function updateStaffMetrics(appointments) {
    const totalEl = document.getElementById('metric-total');
    const confirmedEl = document.getElementById('metric-confirmed');
    const pendingEl = document.getElementById('metric-pending');
    const todayEl = document.getElementById('metric-today');

    const todayStr = getTodayDateString();
    const confirmed = appointments.filter(a => a.status === 'Confirmed').length;
    const pending = appointments.filter(a => a.status === 'Pending Approval').length;
    const todayCount = appointments.filter(a => a.appointment_date === todayStr).length;

    if (totalEl) totalEl.innerText = appointments.length;
    if (confirmedEl) confirmedEl.innerText = confirmed;
    if (pendingEl) pendingEl.innerText = pending;
    if (todayEl) todayEl.innerText = todayCount;
  }

  // Utility Toast System
  function showToast(message, type = 'info') {
    if (!toastContainer) return;

    let icon = 'fa-solid fa-circle-info';
    let bg = 'bg-blue-600 text-white';
    if (type === 'success') {
      icon = 'fa-solid fa-circle-check';
      bg = 'bg-emerald-600 text-white';
    } else if (type === 'warning') {
      icon = 'fa-solid fa-triangle-exclamation';
      bg = 'bg-amber-600 text-white';
    } else if (type === 'error') {
      icon = 'fa-solid fa-circle-xmark';
      bg = 'bg-rose-600 text-white';
    }

    const toast = document.createElement('div');
    toast.className = `flex items-center gap-3 px-4 py-3 rounded-2xl shadow-xl ${bg} text-xs font-semibold transform transition-all duration-300 translate-y-4 opacity-0`;
    toast.innerHTML = `<i class="${icon} text-base"></i> <span>${escapeHtml(message)}</span>`;

    toastContainer.appendChild(toast);
    setTimeout(() => {
      toast.classList.remove('translate-y-4', 'opacity-0');
    }, 10);

    setTimeout(() => {
      toast.classList.add('opacity-0', 'translate-y-2');
      setTimeout(() => toast.remove(), 300);
    }, 3500);
  }

  function closeAllModals() {
    [rescheduleModal, cancelModal, printModal].forEach(m => {
      if (m) m.classList.add('hidden');
    });
    state.activeTrackingAppointment = null;
  }

  // Helpers
  function getTodayDateString() {
    return new Date().toISOString().split('T')[0];
  }

  function getDateOffsetString(offset) {
    const d = new Date();
    d.setDate(d.getDate() + offset);
    return d.toISOString().split('T')[0];
  }

  function formatReadableDate(dateStr) {
    if (!dateStr) return '';
    try {
      const parts = dateStr.split('-');
      const d = new Date(parts[0], parts[1] - 1, parts[2]);
      return d.toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric', year: 'numeric' });
    } catch (e) {
      return dateStr;
    }
  }

  function escapeHtml(str) {
    if (!str) return '';
    return String(str)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#039;');
  }

  function debounce(fn, wait) {
    let t;
    return (...args) => {
      clearTimeout(t);
      t = setTimeout(() => fn(...args), wait);
    };
  }
});
