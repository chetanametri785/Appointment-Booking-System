/**
 * ApexCare Appointments - API Client with Hybrid Server & LocalStorage Fallback
 */

const DEFAULT_SPECIALISTS = [
  {
    id: 1,
    name: "Dr. Sarah Jenkins",
    department: "Cardiology",
    title: "Senior Consultant Cardiologist",
    experience: "14 years exp",
    rating: 4.9,
    consultation_fee: 120,
    room_number: "Suite 302, Wing A",
    image_url: "https://images.unsplash.com/photo-1559839734-2b71ea197ec2?auto=format&fit=crop&q=80&w=300",
    available_days: "Mon,Tue,Wed,Thu,Fri"
  },
  {
    id: 2,
    name: "Dr. Marcus Vance",
    department: "General Medicine",
    title: "Primary Care Physician",
    experience: "10 years exp",
    rating: 4.8,
    consultation_fee: 80,
    room_number: "Room 105, Wing B",
    image_url: "https://images.unsplash.com/photo-1622253692010-333f2da6031d?auto=format&fit=crop&q=80&w=300",
    available_days: "Mon,Tue,Wed,Thu,Fri,Sat"
  },
  {
    id: 3,
    name: "Dr. Elena Rostova",
    department: "Dermatology & Skin",
    title: "Aesthetic & Clinical Dermatologist",
    experience: "12 years exp",
    rating: 4.9,
    consultation_fee: 110,
    room_number: "Room 204, Wing A",
    image_url: "https://images.unsplash.com/photo-1594824813571-638f02614d3f?auto=format&fit=crop&q=80&w=300",
    available_days: "Mon,Wed,Fri,Sat"
  },
  {
    id: 4,
    name: "Dr. Jonathan Hayes",
    department: "Dental & Orthodontics",
    title: "Maxillofacial & Cosmetic Dentist",
    experience: "11 years exp",
    rating: 4.9,
    consultation_fee: 95,
    room_number: "Dental Suite 12",
    image_url: "https://images.unsplash.com/photo-1537368910025-700350fe46c7?auto=format&fit=crop&q=80&w=300",
    available_days: "Mon,Tue,Thu,Fri,Sat"
  },
  {
    id: 5,
    name: "Dr. Amara Patel",
    department: "Pediatrics & Child Health",
    title: "Pediatric Specialist",
    experience: "9 years exp",
    rating: 5.0,
    consultation_fee: 90,
    room_number: "Room 110, Pediatric Care",
    image_url: "https://images.unsplash.com/photo-1651008376811-b90baee60c1f?auto=format&fit=crop&q=80&w=300",
    available_days: "Mon,Tue,Wed,Thu,Fri"
  },
  {
    id: 6,
    name: "Dr. David Kim",
    department: "Orthopedics & Joint Care",
    title: "Orthopedic Surgeon",
    experience: "15 years exp",
    rating: 4.8,
    consultation_fee: 130,
    room_number: "Suite 401, Wing C",
    image_url: "https://images.unsplash.com/photo-1582750433449-648ed127bb54?auto=format&fit=crop&q=80&w=300",
    available_days: "Tue,Wed,Thu,Sat"
  }
];

const STANDARD_TIME_SLOTS = [
  "09:00 AM", "09:30 AM", "10:00 AM", "10:30 AM", "11:00 AM", "11:30 AM",
  "01:30 PM", "02:00 PM", "02:30 PM", "03:00 PM", "03:30 PM", "04:00 PM",
  "05:00 PM", "05:30 PM", "06:00 PM", "06:30 PM"
];

function getSampleDate(dayOffset) {
  const d = new Date();
  d.setDate(d.getDate() + dayOffset);
  return d.toISOString().split('T')[0];
}

const DEFAULT_SAMPLE_APPOINTMENTS = [
  {
    id: 1,
    booking_reference: "APT-2026-101",
    patient_name: "Alex Morgan",
    patient_email: "alex.morgan@example.com",
    patient_phone: "+1 (555) 234-5678",
    specialist_id: 1,
    service_name: "Cardiology Consultation",
    appointment_date: getSampleDate(1),
    appointment_time: "10:00 AM",
    consultation_type: "In-Person Clinic Visit",
    symptoms: "Annual heart rhythm and blood pressure checkup",
    status: "Confirmed",
    created_at: new Date().toISOString()
  },
  {
    id: 2,
    booking_reference: "APT-2026-102",
    patient_name: "Sophia Bennett",
    patient_email: "sophia.b@example.com",
    patient_phone: "+1 (555) 876-5432",
    specialist_id: 3,
    service_name: "Skin Health & Allergy Screening",
    appointment_date: getSampleDate(3),
    appointment_time: "02:30 PM",
    consultation_type: "In-Person Clinic Visit",
    symptoms: "Skin rash consultation and allergy review",
    status: "Confirmed",
    created_at: new Date().toISOString()
  },
  {
    id: 3,
    booking_reference: "APT-2026-103",
    patient_name: "Liam Chen",
    patient_email: "liam.c@example.com",
    patient_phone: "+1 (555) 345-9876",
    specialist_id: 2,
    service_name: "General Health Screening",
    appointment_date: getSampleDate(0),
    appointment_time: "11:30 AM",
    consultation_type: "Video Consultation",
    symptoms: "Mild seasonal fatigue and vitamin check",
    status: "Pending Approval",
    created_at: new Date().toISOString()
  },
  {
    id: 4,
    booking_reference: "APT-2026-104",
    patient_name: "Emma Watson",
    patient_email: "emma.w@example.com",
    patient_phone: "+1 (555) 432-1098",
    specialist_id: 4,
    service_name: "Dental Cleaning & Examination",
    appointment_date: getSampleDate(-1),
    appointment_time: "09:00 AM",
    consultation_type: "In-Person Clinic Visit",
    symptoms: "Routine 6-month hygiene appointment",
    status: "Completed",
    created_at: new Date().toISOString()
  }
];

class AppointmentApiClient {
  constructor() {
    this.serverBase = window.location.origin.includes('http') ? window.location.origin : 'http://127.0.0.1:8000';
    this.useServer = false;
    this.initLocalStorage();
  }

  initLocalStorage() {
    if (!localStorage.getItem('apex_specialists')) {
      localStorage.setItem('apex_specialists', JSON.stringify(DEFAULT_SPECIALISTS));
    }
    if (!localStorage.getItem('apex_appointments')) {
      localStorage.setItem('apex_appointments', JSON.stringify(DEFAULT_SAMPLE_APPOINTMENTS));
    }
  }

  async checkServerConnection() {
    try {
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 1200);
      const res = await fetch(`${this.serverBase}/api/health`, { signal: controller.signal });
      clearTimeout(timeoutId);
      if (res.ok) {
        this.useServer = true;
        return true;
      }
    } catch (e) {
      this.useServer = false;
    }
    return false;
  }

  async getSpecialists() {
    if (this.useServer) {
      try {
        const res = await fetch(`${this.serverBase}/api/specialists`);
        if (res.ok) {
          const data = await res.json();
          return data.specialists;
        }
      } catch (e) {
        console.warn('Server fetch failed, falling back to local data');
      }
    }
    return JSON.parse(localStorage.getItem('apex_specialists') || JSON.stringify(DEFAULT_SPECIALISTS));
  }

  async getSlots(specialistId, dateStr) {
    if (this.useServer) {
      try {
        const res = await fetch(`${this.serverBase}/api/slots?specialist_id=${specialistId}&date=${dateStr}`);
        if (res.ok) {
          const data = await res.json();
          return data.slots;
        }
      } catch (e) {
        console.warn('Server fetch failed for slots, falling back to local');
      }
    }

    // Local storage slot calculation
    const appointments = JSON.parse(localStorage.getItem('apex_appointments') || '[]');
    const booked = appointments
      .filter(a => String(a.specialist_id) === String(specialistId) && a.appointment_date === dateStr && a.status !== 'Cancelled')
      .map(a => a.appointment_time);

    return STANDARD_TIME_SLOTS.map(time => ({
      time,
      is_available: !booked.includes(time)
    }));
  }

  async bookAppointment(formData) {
    if (this.useServer) {
      try {
        const res = await fetch(`${this.serverBase}/api/appointments`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(formData)
        });
        if (res.ok) {
          const data = await res.json();
          return data;
        } else {
          const err = await res.json();
          throw new Error(err.detail || 'Booking failed');
        }
      } catch (e) {
        if (!e.message.includes('booked')) {
          console.warn('Server error, trying local storage mode', e);
        } else {
          throw e;
        }
      }
    }

    // LocalStorage fallback booking
    const specialists = JSON.parse(localStorage.getItem('apex_specialists') || JSON.stringify(DEFAULT_SPECIALISTS));
    const specialist = specialists.find(s => String(s.id) === String(formData.specialist_id));
    const appointments = JSON.parse(localStorage.getItem('apex_appointments') || '[]');

    // Check duplicate slot
    const slotTaken = appointments.some(a => 
      String(a.specialist_id) === String(formData.specialist_id) &&
      a.appointment_date === formData.appointment_date &&
      a.appointment_time === formData.appointment_time &&
      a.status !== 'Cancelled'
    );

    if (slotTaken) {
      throw new Error('Selected time slot is already booked. Please choose another time.');
    }

    const randomSuffix = Math.floor(10000 + Math.random() * 90000);
    const booking_reference = `APT-2026-${randomSuffix}`;

    const newAppointment = {
      id: appointments.length + 1,
      booking_reference,
      patient_name: formData.patient_name,
      patient_email: formData.patient_email,
      patient_phone: formData.patient_phone,
      specialist_id: formData.specialist_id,
      service_name: formData.service_name,
      appointment_date: formData.appointment_date,
      appointment_time: formData.appointment_time,
      consultation_type: formData.consultation_type || 'In-Person Clinic Visit',
      symptoms: formData.symptoms || '',
      status: 'Confirmed',
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
      specialist_name: specialist ? specialist.name : 'Medical Specialist',
      department: specialist ? specialist.department : 'General Medicine',
      room_number: specialist ? specialist.room_number : 'Suite 101',
      consultation_fee: specialist ? specialist.consultation_fee : 100,
      specialist_image: specialist ? specialist.image_url : ''
    };

    appointments.unshift(newAppointment);
    localStorage.setItem('apex_appointments', JSON.stringify(appointments));

    return {
      success: true,
      message: 'Appointment successfully booked!',
      appointment: newAppointment
    };
  }

  async trackAppointment(query) {
    if (!query) return [];
    const qClean = query.trim().toUpperCase();

    if (this.useServer) {
      try {
        const res = await fetch(`${this.serverBase}/api/appointments/track?query=${encodeURIComponent(query.trim())}`);
        if (res.ok) {
          const data = await res.json();
          return data.appointments;
        } else if (res.status === 404) {
          return [];
        }
      } catch (e) {
        console.warn('Server error on track, using local storage');
      }
    }

    // LocalStorage fallback
    const appointments = JSON.parse(localStorage.getItem('apex_appointments') || '[]');
    const specialists = JSON.parse(localStorage.getItem('apex_specialists') || JSON.stringify(DEFAULT_SPECIALISTS));

    const matched = appointments.filter(a => {
      const refMatch = a.booking_reference && a.booking_reference.toUpperCase().includes(qClean);
      const phoneMatch = a.patient_phone && a.patient_phone.replace(/\D/g, '').includes(qClean.replace(/\D/g, ''));
      const emailMatch = a.patient_email && a.patient_email.toUpperCase() === qClean;
      return refMatch || phoneMatch || emailMatch;
    });

    return matched.map(a => {
      const spec = specialists.find(s => String(s.id) === String(a.specialist_id));
      return {
        ...a,
        specialist_name: a.specialist_name || (spec ? spec.name : 'Specialist Doctor'),
        department: a.department || (spec ? spec.department : 'General Consultation'),
        room_number: a.room_number || (spec ? spec.room_number : 'Room 101'),
        specialist_image: a.specialist_image || (spec ? spec.image_url : ''),
        specialist_title: spec ? spec.title : 'Medical Practitioner',
        consultation_fee: a.consultation_fee || (spec ? spec.consultation_fee : 100)
      };
    });
  }

  async getAllAppointments({ status = 'all', search = '', date = '' } = {}) {
    if (this.useServer) {
      try {
        let url = `${this.serverBase}/api/appointments?`;
        if (status && status !== 'all') url += `status=${encodeURIComponent(status)}&`;
        if (search) url += `search=${encodeURIComponent(search)}&`;
        if (date) url += `date_filter=${encodeURIComponent(date)}&`;
        const res = await fetch(url);
        if (res.ok) {
          const data = await res.json();
          return data.appointments;
        }
      } catch (e) {
        console.warn('Server error on getAllAppointments, using local storage');
      }
    }

    const appointments = JSON.parse(localStorage.getItem('apex_appointments') || '[]');
    const specialists = JSON.parse(localStorage.getItem('apex_specialists') || JSON.stringify(DEFAULT_SPECIALISTS));

    let filtered = appointments;
    if (status && status !== 'all') {
      filtered = filtered.filter(a => a.status.toLowerCase() === status.toLowerCase());
    }
    if (date) {
      filtered = filtered.filter(a => a.appointment_date === date);
    }
    if (search) {
      const s = search.toLowerCase();
      filtered = filtered.filter(a =>
        a.booking_reference.toLowerCase().includes(s) ||
        a.patient_name.toLowerCase().includes(s) ||
        a.patient_email.toLowerCase().includes(s) ||
        a.patient_phone.toLowerCase().includes(s)
      );
    }

    return filtered.map(a => {
      const spec = specialists.find(sp => String(sp.id) === String(a.specialist_id));
      return {
        ...a,
        specialist_name: a.specialist_name || (spec ? spec.name : 'Specialist Doctor'),
        department: a.department || (spec ? spec.department : 'General Medicine'),
        room_number: a.room_number || (spec ? spec.room_number : 'Room 101'),
        consultation_fee: a.consultation_fee || (spec ? spec.consultation_fee : 100),
        specialist_image: a.specialist_image || (spec ? spec.image_url : '')
      };
    });
  }

  async updateStatus(bookingRef, newStatus) {
    if (this.useServer) {
      try {
        const res = await fetch(`${this.serverBase}/api/appointments/${bookingRef}/status`, {
          method: 'PATCH',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ status: newStatus })
        });
        if (res.ok) {
          const data = await res.json();
          return data;
        }
      } catch (e) {
        console.warn('Server error on updateStatus, falling back to local');
      }
    }

    const appointments = JSON.parse(localStorage.getItem('apex_appointments') || '[]');
    const idx = appointments.findIndex(a => a.booking_reference.toUpperCase() === bookingRef.toUpperCase());
    if (idx !== -1) {
      appointments[idx].status = newStatus;
      appointments[idx].updated_at = new Date().toISOString();
      localStorage.setItem('apex_appointments', JSON.stringify(appointments));
      return { success: true, message: `Status updated to ${newStatus}`, appointment: appointments[idx] };
    }
    throw new Error('Appointment not found');
  }

  async reschedule(bookingRef, newDate, newTime) {
    if (this.useServer) {
      try {
        const res = await fetch(`${this.serverBase}/api/appointments/${bookingRef}/reschedule`, {
          method: 'PATCH',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ appointment_date: newDate, appointment_time: newTime })
        });
        if (res.ok) {
          const data = await res.json();
          return data;
        } else {
          const err = await res.json();
          throw new Error(err.detail || 'Reschedule failed');
        }
      } catch (e) {
        if (!e.message.includes('taken')) {
          console.warn('Server error on reschedule, falling back to local');
        } else {
          throw e;
        }
      }
    }

    const appointments = JSON.parse(localStorage.getItem('apex_appointments') || '[]');
    const idx = appointments.findIndex(a => a.booking_reference.toUpperCase() === bookingRef.toUpperCase());
    if (idx !== -1) {
      const apt = appointments[idx];
      // Check slot availability
      const taken = appointments.some(a => 
        a.booking_reference !== bookingRef &&
        String(a.specialist_id) === String(apt.specialist_id) &&
        a.appointment_date === newDate &&
        a.appointment_time === newTime &&
        a.status !== 'Cancelled'
      );
      if (taken) {
        throw new Error('Selected time slot on the new date is already taken.');
      }
      apt.appointment_date = newDate;
      apt.appointment_time = newTime;
      apt.status = 'Confirmed';
      apt.updated_at = new Date().toISOString();
      localStorage.setItem('apex_appointments', JSON.stringify(appointments));
      return { success: true, message: 'Appointment rescheduled successfully!', appointment: apt };
    }
    throw new Error('Appointment not found');
  }
}

// Global instance
window.apiClient = new AppointmentApiClient();
